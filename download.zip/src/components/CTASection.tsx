
"use client";

import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

export default function CTASection() {
  return (
    <section className="py-24 px-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-primary/5 pointer-events-none" />
      <div className="max-w-5xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="glass-card p-12 md:p-20 rounded-3xl text-center border-primary/20 shadow-2xl shadow-primary/10"
        >
          <h2 className="text-4xl md:text-6xl font-headline font-bold text-white mb-6">
            Ready to <span className="text-primary">Atomize</span> your workflow?
          </h2>
          <p className="text-white/60 text-lg mb-10 max-w-2xl mx-auto">
            Join thousands of professionals who save hours every week by chatting with their documents instead of manually searching them.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <Link
              href="/signup"
              className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-white px-10 py-4 rounded-xl font-bold transition-all text-lg flex items-center justify-center gap-2"
            >
              Get Started for Free
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link
              href="/pricing"
              className="w-full sm:w-auto border border-white/10 hover:bg-white/5 text-white px-10 py-4 rounded-xl font-bold transition-all text-lg"
            >
              View All Plans
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
