'use server';
/**
 * @fileOverview A simple AI explainer agent.
 *
 * - explainSimply - A function that handles the simple explanation process.
 * - ExplainerInput - The input type for the explainSimply function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ExplainerInputSchema = z.object({
  topic: z.string().default('AI').describe('The topic to explain simply.'),
});
export type ExplainerInput = z.infer<typeof ExplainerInputSchema>;

export async function explainSimply(input: ExplainerInput): Promise<string> {
  return explainSimplyFlow(input);
}

const explainSimplyFlow = ai.defineFlow(
  {
    name: 'explainSimplyFlow',
    inputSchema: ExplainerInputSchema,
    outputSchema: z.string(),
  },
  async (input) => {
    const {text} = await ai.generate({
      model: 'googleai/gemini-1.5-flash',
      prompt: `Explain ${input.topic} simply, like I'm five years old.`,
    });
    return text;
  }
);
