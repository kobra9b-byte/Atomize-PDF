"use client";

import Navbar from "@/components/Navbar";
import FooterSection from "@/components/FooterSection";
import { motion } from "framer-motion";

export default function PrivacyPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <main className="flex-1 max-w-3xl mx-auto py-20 px-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-8"
        >
          <h1 className="text-4xl font-headline font-bold text-white mb-8">Privacy Policy</h1>

          <div className="prose prose-invert max-w-none space-y-6 text-muted-foreground leading-relaxed">
            <p className="text-lg text-white/80">
              Your privacy is paramount at Atomize PDF. This policy outlines how we handle your data and the steps we take to protect your information.
            </p>

            <section className="space-y-4">
              <h2 className="text-2xl font-headline font-semibold text-white">Data Processing</h2>
              <p>
                We respect your privacy. Your data—including PDF uploads, split fragments, and document metadata—are processed securely. We leverage industry-standard encryption and secure cloud environments to ensure your files are only accessible to you and your authorized team members.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-2xl font-headline font-semibold text-white">No Third-Party Sharing</h2>
              <p>
                Your uploads and processed documents are never shared with third parties for marketing, training, or profiling purposes. We act solely as a processor for your document management needs.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-2xl font-headline font-semibold text-white">Usage Data</h2>
              <p>
                We may collect basic, anonymous usage data (such as feature engagement and processing frequency) to improve our AI models and platform performance. This data is aggregated and does not identify individual users or document contents.
              </p>
            </section>

            <section className="space-y-4">
              <h2 className="text-2xl font-headline font-semibold text-white">Data Retention</h2>
              <p>
                You have full control over your data. You can delete your processing history and associated files at any time through the Dashboard settings.
              </p>
            </section>
          </div>
        </motion.div>
      </main>
      <FooterSection />
    </div>
  );
}
