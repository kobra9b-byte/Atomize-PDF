import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { initializeFirebase } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";

export const dynamic = 'force-dynamic';

/**
 * Stripe Webhook Handler
 * Processes 'checkout.session.completed' events to update user plans and usage.
 */
export async function POST(req: Request) {
  const body = await req.text();
  const headersList = await headers();
  const signature = headersList.get("Stripe-Signature") as string;

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const { db } = initializeFirebase();

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as any;
    const userId = session.metadata?.userId || session.client_reference_id;
    const plan = session.metadata?.plan || "pro";

    if (userId) {
      try {
        // 🔥 Use numeric timestamp for consistency
        await setDoc(doc(db, "users", userId), {
          plan: plan.toUpperCase(),
          updatedAt: Date.now(),
          subscriptionId: session.subscription,
          messagesUsed: 0,
          pdfsUsed: 0,
          resetDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        }, { merge: true });
        
        console.log(`Webhook: Activated ${plan.toUpperCase()} for user ${userId}`);
      } catch (dbError) {
        console.error("Webhook: Firestore update failed", dbError);
        return NextResponse.json({ error: "Internal database error" }, { status: 500 });
      }
    }
  }

  return NextResponse.json({ received: true });
}
