import { NextResponse } from "next/server";
import { headers } from "next/headers";
import { stripe } from "@/lib/stripe";
import { initializeFirebase } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";

export const dynamic = 'force-dynamic';

export async function POST(req: Request) {
  const body = await req.text();
  const signature = (await headers()).get("Stripe-Signature") as string;

  let event;

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    );
  } catch (err: any) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  const { db } = initializeFirebase();

  if (event.type === "checkout.session.completed") {
    const session = event.data.object as any;
    const userId = session.metadata?.userId || session.client_reference_id;
    const plan = session.metadata?.plan || "pro";

    if (userId) {
      try {
        await setDoc(doc(db, "users", userId), {
          plan: plan,
          updatedAt: new Date().toISOString(),
          subscriptionId: session.subscription,
          messagesUsed: 0,
          pdfsUsed: 0,
          resetDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        }, { merge: true });
        console.log(`Successfully updated User ${userId} to plan: ${plan}`);
      } catch (dbError) {
        console.error("Error updating user plan in Firestore:", dbError);
        return NextResponse.json({ error: "Firestore update failed" }, { status: 500 });
      }
    }
  }

  return NextResponse.json({ received: true });
}
