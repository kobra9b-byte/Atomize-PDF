"use client";

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import Navbar from "@/components/Navbar";
import FooterSection from "@/components/FooterSection";
import { motion } from "framer-motion";
import { Mail, MessageSquare, Send } from "lucide-react";

export default function ContactPage() {
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    setTimeout(() => {
      toast({
        title: "Message sent! 🚀",
        description: "We'll get back to you as soon as possible.",
      });
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#0B1120]">
      <Navbar />
      <main className="flex-1 flex items-center justify-center py-20 px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          className="w-full max-w-2xl"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-start">
            <div className="md:col-span-1 space-y-6">
              <div className="space-y-2">
                <h2 className="text-2xl font-headline font-bold text-white">Get in touch</h2>
                <p className="text-white/40 text-sm">Have a question? We're here to help.</p>
              </div>
              <div className="space-y-4">
                <div className="flex items-center gap-3 text-white/60">
                  <Mail className="w-4 h-4 text-primary" />
                  <span className="text-sm">support@atomize.com</span>
                </div>
                <div className="flex items-center gap-3 text-white/60">
                  <MessageSquare className="w-4 h-4 text-primary" />
                  <span className="text-sm">Live chat available 24/7</span>
                </div>
              </div>
            </div>

            <Card className="md:col-span-2 glass-card border-white/5 bg-white/[0.02] shadow-2xl">
              <CardContent className="p-6">
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-white/60">Email Address</Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="name@company.com"
                      required
                      className="bg-white/5 border-white/10 text-white h-12 focus:ring-primary/50"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="message" className="text-white/60">How can we help?</Label>
                    <Textarea
                      id="message"
                      placeholder="Tell us about your project or inquiry..."
                      required
                      className="bg-white/5 border-white/10 text-white min-h-[150px] resize-none focus:ring-primary/50"
                    />
                  </div>

                  <Button type="submit" disabled={isSubmitting} className="w-full bg-primary hover:bg-primary/90 text-white font-bold h-12 text-base transition-all shadow-lg shadow-primary/20">
                    {isSubmitting ? "Sending..." : "Send Message"}
                    {!isSubmitting && <Send className="w-4 h-4 ml-2" />}
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </motion.div>
      </main>
      <FooterSection />
    </div>
  );
}
