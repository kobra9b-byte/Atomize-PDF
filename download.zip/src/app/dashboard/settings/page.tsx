
"use client";

import { useState } from 'react';
import { 
  User, 
  Settings, 
  Bell, 
  Shield, 
  CreditCard, 
  Database,
  Save,
  Trash2
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

export default function SettingsPage() {
  const { toast } = useToast();
  const [isSaving, setIsSaving] = useState(false);

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      toast({
        title: "Settings Saved",
        description: "Your preferences have been updated successfully.",
      });
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h2 className="text-2xl font-headline font-bold text-white">Settings</h2>
        <p className="text-muted-foreground text-sm">Manage your account and platform preferences.</p>
      </div>

      <Tabs defaultValue="profile" className="space-y-6">
        <TabsList className="bg-white/5 border border-white/10">
          <TabsTrigger value="profile" className="data-[state=active]:bg-primary">Profile</TabsTrigger>
          <TabsTrigger value="notifications" className="data-[state=active]:bg-primary">Notifications</TabsTrigger>
          <TabsTrigger value="billing" className="data-[state=active]:bg-primary">Billing</TabsTrigger>
          <TabsTrigger value="security" className="data-[state=active]:bg-primary">Security</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-6">
          <Card className="glass-card p-6 space-y-6">
            <div className="flex items-center gap-4">
              <div className="w-20 h-20 rounded-2xl bg-white/5 border border-white/10 flex items-center justify-center">
                <User className="w-8 h-8 text-white/20" />
              </div>
              <div className="space-y-2">
                <h4 className="font-semibold text-white">Profile Photo</h4>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="h-8 bg-white/5 border-white/10">Change</Button>
                  <Button variant="ghost" size="sm" className="h-8 text-destructive hover:text-destructive hover:bg-destructive/10">Remove</Button>
                </div>
              </div>
            </div>

            <Separator className="bg-white/5" />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullname">Full Name</Label>
                <Input id="fullname" defaultValue="Alex Rivera" className="bg-white/5 border-white/10 text-white" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email">Email Address</Label>
                <Input id="email" defaultValue="alex@atomize.com" className="bg-white/5 border-white/10 text-white" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="bio">Bio</Label>
              <Input id="bio" placeholder="Tell us about yourself..." className="bg-white/5 border-white/10 text-white" />
            </div>

            <div className="flex justify-end pt-4">
              <Button onClick={handleSave} disabled={isSaving} className="bg-primary text-white">
                {isSaving ? "Saving..." : "Save Changes"}
                {!isSaving && <Save className="w-4 h-4 ml-2" />}
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="notifications" className="space-y-6">
          <Card className="glass-card p-6 space-y-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-white">Email Notifications</Label>
                  <p className="text-xs text-muted-foreground">Receive emails when processing is complete.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-white/5" />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-white">Usage Alerts</Label>
                  <p className="text-xs text-muted-foreground">Get notified when you approach your cloud limits.</p>
                </div>
                <Switch defaultChecked />
              </div>
              <Separator className="bg-white/5" />
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label className="text-white">Marketing Emails</Label>
                  <p className="text-xs text-muted-foreground">Stay updated with new AI features and tips.</p>
                </div>
                <Switch />
              </div>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="billing" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="glass-card p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <CreditCard className="w-5 h-5 text-primary" />
                </div>
                <Badge className="bg-green-500/10 text-green-500 border-0 uppercase text-[10px]">Active</Badge>
              </div>
              <div>
                <h4 className="font-semibold text-white">Pro Plan</h4>
                <p className="text-xs text-muted-foreground">Renews on March 15, 2024</p>
              </div>
              <Button variant="outline" className="w-full bg-white/5 border-white/10">Manage Billing</Button>
            </Card>

            <Card className="glass-card p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center">
                  <Database className="w-5 h-5 text-secondary" />
                </div>
              </div>
              <div>
                <h4 className="font-semibold text-white">Storage Usage</h4>
                <p className="text-xs text-muted-foreground">450MB of 1GB Used</p>
              </div>
              <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                <div className="bg-secondary h-full w-[45%]" />
              </div>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="security" className="space-y-6">
          <Card className="glass-card p-6 border-destructive/20 bg-destructive/5 space-y-4">
            <div className="flex items-center gap-4 text-destructive">
              <Trash2 className="w-6 h-6" />
              <div>
                <h4 className="font-semibold">Danger Zone</h4>
                <p className="text-xs opacity-70">Irreversibly delete your account and all associated data.</p>
              </div>
            </div>
            <Button variant="destructive" className="w-full md:w-auto">Delete Account</Button>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
