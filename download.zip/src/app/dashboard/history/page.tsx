
"use client";

import { motion } from 'framer-motion';
import { 
  History, 
  FileText, 
  Calendar, 
  Download, 
  MoreVertical,
  Search,
  Filter
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from '@/components/ui/badge';
import { useCollection, useFirestore, useMemoFirebase, useUser } from '@/firebase';
import { collection, query, orderBy, where } from 'firebase/firestore';

export default function ActivityLogsPage() {
  const firestore = useFirestore();
  const { user } = useUser();

  const historyQuery = useMemoFirebase(() => {
    if (!firestore || !user) return null;
    return query(
      collection(firestore, 'history'), 
      where('userId', '==', user.uid),
      orderBy('timestamp', 'desc')
    );
  }, [firestore, user]);

  const { data: logs, loading } = useCollection(historyQuery);

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-headline font-bold text-white">Activity Logs</h2>
          <p className="text-muted-foreground text-sm">Monitor all your recent PDF splitting activities.</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
            <Input 
              placeholder="Search documents..." 
              className="pl-10 bg-white/5 border-white/10 w-[250px]"
            />
          </div>
          <Button variant="outline" className="bg-white/5 border-white/10">
            <Filter className="w-4 h-4 mr-2" />
            Filter
          </Button>
        </div>
      </div>

      <Card className="glass-card overflow-hidden">
        <Table>
          <TableHeader className="bg-white/[0.02]">
            <TableRow className="hover:bg-transparent border-white/5">
              <TableHead className="text-white/60">Document</TableHead>
              <TableHead className="text-white/60">Date</TableHead>
              <TableHead className="text-white/60">Splits</TableHead>
              <TableHead className="text-white/60">Status</TableHead>
              <TableHead className="text-right text-white/60">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <TableRow key={i} className="border-white/5">
                  <TableCell><div className="h-4 w-32 bg-white/5 animate-pulse rounded" /></TableCell>
                  <TableCell><div className="h-4 w-24 bg-white/5 animate-pulse rounded" /></TableCell>
                  <TableCell><div className="h-4 w-12 bg-white/5 animate-pulse rounded" /></TableCell>
                  <TableCell><div className="h-4 w-16 bg-white/5 animate-pulse rounded" /></TableCell>
                  <TableCell className="text-right"><div className="h-8 w-8 bg-white/5 animate-pulse rounded ml-auto" /></TableCell>
                </TableRow>
              ))
            ) : logs && logs.length > 0 ? (
              logs.map((log: any) => (
                <TableRow key={log.id} className="hover:bg-white/[0.02] border-white/5 transition-colors">
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded bg-red-500/10 flex items-center justify-center">
                        <FileText className="w-4 h-4 text-red-500" />
                      </div>
                      <span className="text-white truncate max-w-[200px]">{log.filename}</span>
                    </div>
                  </TableCell>
                  <TableCell className="text-white/60">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-3 h-3" />
                      {log.timestamp?.toDate ? log.timestamp.toDate().toLocaleDateString() : new Date(log.timestamp).toLocaleDateString()}
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="secondary" className="bg-primary/10 text-primary border-0">
                      {log.splitsCount} parts
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className={`flex items-center gap-2 text-xs ${log.status === 'completed' ? 'text-green-400' : 'text-orange-400'}`}>
                      <div className={`w-1.5 h-1.5 rounded-full ${log.status === 'completed' ? 'bg-green-400' : 'bg-orange-400'}`} />
                      {log.status.charAt(0).toUpperCase() + log.status.slice(1)}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button variant="ghost" size="icon" className="text-white/40 hover:text-white">
                      <Download className="w-4 h-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={5} className="h-64 text-center">
                  <div className="flex flex-col items-center justify-center text-white/40">
                    <History className="w-10 h-10 mb-4 opacity-20" />
                    <p>No activity recorded yet.</p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
