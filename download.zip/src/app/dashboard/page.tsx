
"use client";

import { useState, useEffect, useRef } from "react";
import { useRouter } from "next/navigation";
import { useUser, useAuth, useFirestore } from "@/firebase";
import { signOut } from "firebase/auth";
import { doc, onSnapshot, updateDoc, increment, collection, addDoc } from "firebase/firestore";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Send, 
  Loader2, 
  Sparkles, 
  FileUp, 
  FileText, 
  X, 
  LogOut,
  History
} from "lucide-react";
import Link from "next/link";
import { generalChat } from "@/ai/flows/chat-flow";
import { useToast } from "@/hooks/use-toast";
import { LIMITS, type PlanType, canSendMessage, canUploadPDF, shouldReset } from "@/lib/limits";
import { errorEmitter } from "@/firebase/error-emitter";
import { FirestorePermissionError } from "@/firebase/errors";

export default function Dashboard() {
  const router = useRouter();
  const { user, loading: userLoading } = useUser();
  const auth = useAuth();
  const db = useFirestore();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [message, setMessage] = useState("");
  const [chat, setChat] = useState<{ role: 'user' | 'model', content: string, sources?: string[] }[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [attachedFile, setAttachedFile] = useState<{ name: string, text: string } | null>(null);
  
  const [userData, setUserData] = useState<any>(null);
  const [isPlanLoading, setIsPlanLoading] = useState(true);

  // Sync user data
  useEffect(() => {
    if (!userLoading && !user) {
      router.replace("/signin");
      return;
    }

    if (user) {
      const userRef = doc(db, 'users', user.uid);
      const unsubscribe = onSnapshot(userRef, (snap) => {
        if (snap.exists()) {
          setUserData(snap.data());
        } else {
          setUserData({ plan: "free", messagesUsed: 0, pdfsUsed: 0 });
        }
        setIsPlanLoading(false);
      }, () => setIsPlanLoading(false));

      return () => unsubscribe();
    }
  }, [user, userLoading, router, db]);

  // Handle monthly resets
  useEffect(() => {
    if (userData?.resetDate && shouldReset(userData.resetDate) && user) {
      const nextResetDate = new Date();
      nextResetDate.setMonth(nextResetDate.getMonth() + 1);
      const nextResetStr = nextResetDate.toISOString().split('T')[0];

      const userRef = doc(db, "users", user.uid);
      updateDoc(userRef, {
        messagesUsed: 0,
        pdfsUsed: 0,
        resetDate: nextResetStr,
      }).catch(async () => {
        errorEmitter.emit('permission-error', new FirestorePermissionError({
          path: userRef.path,
          operation: 'update',
          requestResourceData: { messagesUsed: 0 },
        }));
      });

      toast({ title: "Limits Reset 🔄", description: "Your monthly usage limits have been refreshed." });
    }
  }, [userData, user, db, toast]);

  const handleLogout = async () => {
    await signOut(auth);
    router.replace("/signin");
  };

  const currentPlan: PlanType = (userData?.plan?.toLowerCase() || "free") as PlanType;
  const planLimits = LIMITS[currentPlan] || LIMITS.free;

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!canUploadPDF(currentPlan, userData?.pdfsUsed || 0)) {
      toast({
        title: "Limit Reached 🚫",
        description: `Upgrade to upload more PDFs. Limit: ${planLimits.pdfs}`,
        variant: "destructive",
      });
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await fetch('/api/upload', { method: 'POST', body: formData });
      const data = await res.json();
      if (data.error) throw new Error(data.error);

      const userRef = doc(db, 'users', user!.uid);
      updateDoc(userRef, { pdfsUsed: increment(1) });

      addDoc(collection(db, 'history'), {
        userId: user!.uid,
        filename: file.name,
        timestamp: new Date().toISOString(),
        splitsCount: data.numpages || 1,
        status: 'completed',
        downloadUrl: ''
      });

      setAttachedFile({ name: file.name, text: data.text });
      toast({ title: "PDF Ready", description: `${file.name} is processed.` });
    } catch (error: any) {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    } finally {
      setIsUploading(false);
    }
  };

  const handleSendMessage = async () => {
    if ((!message.trim() && !attachedFile) || isAiLoading) return;

    // Strict Usage Check for FREE plan (10 message limit)
    const usage = userData?.messagesUsed || 0;
    if (currentPlan.toUpperCase() === "FREE" && usage >= 10) {
      toast({ 
        title: "Limit Reached 🚫", 
        description: "Upgrade to Pro to continue chatting.", 
        variant: "destructive" 
      });
      return;
    }

    if (!canSendMessage(currentPlan, usage)) {
      toast({ title: "Limit Reached 🚫", description: "Message limit reached for your current plan.", variant: "destructive" });
      return;
    }

    const userMsg = message || `Analyzing ${attachedFile?.name}`;
    setChat(prev => [...prev, { role: 'user', content: userMsg }]);
    setMessage("");
    setIsAiLoading(true);

    try {
      const result = await generalChat({
        message: userMsg,
        documentContext: attachedFile?.text,
        history: chat.map(m => ({ role: m.role, content: m.content }))
      });
      
      const userRef = doc(db, 'users', user!.uid);
      updateDoc(userRef, { messagesUsed: increment(1) });
      
      setChat(prev => [...prev, { role: 'model', content: result.answer, sources: result.sources }]);
    } catch (err: any) {
      setChat(prev => [...prev, { role: 'model', content: "Error communicating with AI." }]);
      toast({ title: "Processing Error", description: err.message, variant: "destructive" });
    } finally {
      setIsAiLoading(false);
    }
  };

  if (userLoading || isPlanLoading) return <div className="min-h-screen bg-[#0B1120] flex items-center justify-center"><Loader2 className="animate-spin text-primary" /></div>;

  return (
    <div className="space-y-6 max-w-6xl mx-auto h-[calc(100vh-140px)] flex flex-col">
      <div className="flex justify-between items-center shrink-0">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-primary to-secondary flex items-center justify-center shadow-lg"><Sparkles className="w-5 h-5 text-white" /></div>
          <div>
            <h1 className="text-xl font-headline font-bold text-white">AI Workspace</h1>
            <p className="text-white/40 text-xs">Plan: <span className="uppercase text-primary font-bold">{currentPlan}</span></p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          {currentPlan.toLowerCase() === "free" && (
            <button
              onClick={() => router.push("/pricing")}
              className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-lg font-bold flex items-center gap-2 transition-all shadow-lg shadow-yellow-500/20"
            >
              Upgrade 🚀
            </button>
          )}
          <Button onClick={handleLogout} variant="ghost" size="sm" className="text-white/40 hover:text-white"><LogOut className="w-4 h-4 mr-2" />Sign Out</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 flex-1 overflow-hidden">
        <Card className="lg:col-span-3 glass-card flex flex-col overflow-hidden">
          <CardHeader className="border-b border-white/5 py-3 px-6"><CardTitle className="text-xs font-semibold text-white/60">PDF AI ASSISTANT</CardTitle></CardHeader>
          <CardContent className="flex-1 p-0 overflow-hidden relative">
            <ScrollArea className="h-full p-6">
              <div className="space-y-6">
                {chat.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-64 text-center space-y-4">
                    <FileText className="w-10 h-10 text-primary/20" />
                    <p className="text-sm text-white/40">Upload a PDF to start analysis.</p>
                  </div>
                )}
                {chat.map((msg, i) => (
                  <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className="max-w-[85%] space-y-1">
                      <div className={`p-4 rounded-2xl text-sm ${msg.role === 'user' ? 'bg-primary text-white rounded-tr-none' : 'bg-white/5 text-white/80 border border-white/5 rounded-tl-none whitespace-pre-wrap'}`}>{msg.content}</div>
                      {msg.sources && msg.sources.length > 0 && <div className="text-[10px] text-white/20 italic px-2">Source context applied</div>}
                    </div>
                  </div>
                ))}
                {isAiLoading && <div className="flex justify-start"><Loader2 className="animate-spin text-primary/40" /></div>}
              </div>
            </ScrollArea>
          </CardContent>
          <CardFooter className="p-4 border-t border-white/5 bg-black/20 flex-col gap-3">
            {attachedFile && <div className="w-full flex justify-between bg-primary/10 p-2 rounded-lg border border-primary/20"><span className="text-xs font-bold text-white truncate">{attachedFile.name}</span><Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => setAttachedFile(null)}><X className="h-3 w-3" /></Button></div>}
            <div className="flex w-full gap-2">
              <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept="application/pdf" />
              <Button variant="outline" size="icon" className="h-12 w-12" onClick={() => fileInputRef.current?.click()} disabled={isUploading}><FileUp className="w-4 h-4" /></Button>
              <Input value={message} onChange={(e) => setMessage(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} placeholder="Ask anything about the document..." className="bg-white/5 h-12" />
              <Button onClick={handleSendMessage} disabled={isAiLoading || (!message.trim() && !attachedFile)} className="h-12 w-12"><Send className="w-4 h-4" /></Button>
            </div>
          </CardFooter>
        </Card>

        <div className="flex flex-col gap-6">
          <Card className="glass-card p-5 space-y-6">
            <h3 className="text-xs font-bold text-white/40 uppercase">Workspace Usage</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-white/40">Messages</span>
                  <span className="text-white">{userData?.messagesUsed || 0} / {planLimits.messages === Infinity ? '∞' : planLimits.messages}</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                  <div className="bg-primary h-full transition-all" style={{ width: `${Math.min(((userData?.messagesUsed || 0) / (planLimits.messages || 1)) * 100, 100)}%` }} />
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-[11px] font-bold">
                  <span className="text-white/40">PDFs</span>
                  <span className="text-white">{userData?.pdfsUsed || 0} / {planLimits.pdfs === Infinity ? '∞' : planLimits.pdfs}</span>
                </div>
                <div className="w-full bg-white/5 h-1 rounded-full overflow-hidden">
                  <div className="bg-secondary h-full transition-all" style={{ width: `${Math.min(((userData?.pdfsUsed || 0) / (planLimits.pdfs || 1)) * 100, 100)}%` }} />
                </div>
              </div>
              {userData?.resetDate && <p className="text-[10px] text-white/20 italic">Next reset: {userData.resetDate}</p>}
            </div>
          </Card>
          <Button variant="outline" className="w-full justify-start gap-3 border-white/5 h-auto py-4" asChild><Link href="/dashboard/history"><History className="w-4 h-4 text-orange-500" /><div><div className="text-xs font-bold text-white">Activity Logs</div><div className="text-[10px] text-white/40">View split history</div></div></Link></Button>
        </div>
      </div>
    </div>
  );
}
