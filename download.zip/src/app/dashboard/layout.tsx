import { SidebarProvider, SidebarInset } from '@/components/ui/sidebar';
import { DashboardSidebar } from '@/components/DashboardSidebar';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-[#0B1120]">
        <DashboardSidebar />
        <SidebarInset className="bg-[#0B1120]">
          <div className="flex flex-col h-full">
            <header className="h-16 border-b border-white/5 flex items-center px-6 bg-[#0B1120]/50 backdrop-blur-sm sticky top-0 z-40">
              <h1 className="font-headline font-bold text-lg text-white">Workspace</h1>
            </header>
            <main className="flex-1 p-6 overflow-y-auto">
              {children}
            </main>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
