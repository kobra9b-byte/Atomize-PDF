
"use client";

import { motion } from 'framer-motion';
import { 
  Users, 
  UserPlus, 
  Mail, 
  Shield, 
  MoreHorizontal,
  CheckCircle2
} from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';

const members = [
  {
    name: "Alex Rivera",
    email: "alex@atomize.com",
    role: "Admin",
    status: "Active",
    avatar: "https://picsum.photos/seed/alex/100/100"
  },
  {
    name: "Sarah Chen",
    email: "sarah@atomize.com",
    role: "Editor",
    status: "Active",
    avatar: "https://picsum.photos/seed/sarah/100/100"
  },
  {
    name: "Jordan Smith",
    email: "jordan@atomize.com",
    role: "Viewer",
    status: "Pending",
    avatar: "https://picsum.photos/seed/jordan/100/100"
  }
];

export default function TeamHubPage() {
  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-headline font-bold text-white">Team Hub</h2>
          <p className="text-muted-foreground text-sm">Manage your team members and their access levels.</p>
        </div>
        <Button className="bg-primary text-white">
          <UserPlus className="w-4 h-4 mr-2" />
          Invite Member
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Card className="glass-card p-6 border-primary/20 bg-primary/5 flex flex-col items-center text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
            <Shield className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h4 className="font-semibold text-white">Team Plan</h4>
            <p className="text-xs text-muted-foreground">You are using the Pro Business tier.</p>
          </div>
          <Button variant="outline" size="sm" className="w-full bg-white/5 border-white/10">
            Manage Subscription
          </Button>
        </Card>

        <Card className="glass-card p-6 flex flex-col items-center text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-secondary/10 flex items-center justify-center">
            <Users className="w-6 h-6 text-secondary" />
          </div>
          <div>
            <h4 className="font-semibold text-white">Team Seats</h4>
            <p className="text-xs text-muted-foreground">3 of 10 seats currently occupied.</p>
          </div>
          <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
            <div className="bg-secondary h-full w-[30%]" />
          </div>
        </Card>

        <Card className="glass-card p-6 flex flex-col items-center text-center space-y-4">
          <div className="w-12 h-12 rounded-full bg-green-500/10 flex items-center justify-center">
            <CheckCircle2 className="w-6 h-6 text-green-500" />
          </div>
          <div>
            <h4 className="font-semibold text-white">Activity Pulse</h4>
            <p className="text-xs text-muted-foreground">All systems operational.</p>
          </div>
          <Button variant="ghost" size="sm" className="w-full text-white/40 hover:text-white">
            View Health Stats
          </Button>
        </Card>
      </div>

      <Card className="glass-card overflow-hidden">
        <div className="p-6 border-b border-white/5 flex items-center justify-between">
          <h3 className="font-semibold text-white">Current Members</h3>
          <Badge variant="outline" className="border-white/10 text-white/60">3 Members</Badge>
        </div>
        <div className="divide-y divide-white/5">
          {members.map((member, i) => (
            <div key={i} className="p-4 flex items-center justify-between hover:bg-white/[0.01] transition-colors">
              <div className="flex items-center gap-4">
                <Avatar className="h-10 w-10 border border-white/10">
                  <AvatarImage src={member.avatar} alt={member.name} />
                  <AvatarFallback>{member.name[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium text-white text-sm">{member.name}</span>
                    {member.status === 'Pending' && (
                      <Badge className="bg-orange-500/10 text-orange-500 border-0 h-4 text-[10px]">Pending</Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Mail className="w-3 h-3" />
                    {member.email}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Badge variant="outline" className="border-white/10 text-white/40 font-normal">
                  {member.role}
                </Badge>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8 text-white/40 hover:text-white">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="glass-card border-white/10">
                    <DropdownMenuItem>Edit Permissions</DropdownMenuItem>
                    <DropdownMenuItem className="text-destructive">Remove Access</DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
