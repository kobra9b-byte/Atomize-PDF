"use client";

import Navbar from "@/components/Navbar";
import FooterSection from "@/components/FooterSection";
import PricingSection from "@/components/PricingSection";
import FAQSection from "@/components/FAQSection";
import CTASection from "@/components/CTASection";
import { motion } from "framer-motion";
import { Sparkles } from "lucide-react";

export default function PricingPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0B1120]">
      <Navbar />
      <main className="flex-1">
        {/* Hero Section */}
        <section className="py-24 px-6 relative overflow-hidden text-center">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-full max-w-4xl bg-primary/10 blur-[120px] rounded-full pointer-events-none" />
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="max-w-4xl mx-auto relative z-10"
          >
            <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
              <div className="flex items-center gap-2 text-primary text-xs font-bold uppercase tracking-wider">
                <Sparkles className="w-3 h-3" />
                <span>Annual Billing</span>
              </div>
              <div className="w-px h-3 bg-white/10" />
              <span className="text-green-400 text-sm font-bold tracking-tight">
                وفر 20%
              </span>
            </div>
            <h1 className="text-5xl md:text-7xl font-headline font-bold text-white mb-6 tracking-tight">
              اختر خطتك <span className="gradient-text">المثالية</span> 🚀
            </h1>
            <p className="text-white/40 text-xl max-w-2xl mx-auto leading-relaxed">
              ابدأ مجانًا وطور تجربتك مع أقوى تقنيات الذكاء الاصطناعي لمعالجة مستنداتك باحترافية وسرعة.
            </p>
          </motion.div>
        </section>

        {/* Pricing Grid */}
        <section className="pb-24">
          <PricingSection />
        </section>

        {/* Features Comparison */}
        <section className="py-24 border-t border-white/5">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-headline font-bold text-white mb-4">قارن بين المميزات</h2>
              <p className="text-white/40">كل ما تحتاجه لإدارة مستنداتك في مكان واحد</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {[
                { title: "دقة AI متناهية", desc: "نستخدم أحدث الموديلات لضمان دقة الإجابات." },
                { title: "تشفير كامل", desc: "بياناتك مشفرة ومحمية بخصوصية تامة." },
                { title: "سرعة البرق", desc: "معالجة ملفاتك في ثوانٍ معدودة." },
                { title: "دعم فني متواصل", desc: "فريقنا معك في كل خطوة." }
              ].map((item, i) => (
                <div key={i} className="glass-card p-6 rounded-2xl border-white/5">
                  <h4 className="text-white font-bold mb-2">{item.title}</h4>
                  <p className="text-white/40 text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ Section */}
        <FAQSection />

        {/* CTA Section */}
        <div className="py-20">
          <CTASection />
        </div>
      </main>
      <FooterSection />
    </div>
  );
}
